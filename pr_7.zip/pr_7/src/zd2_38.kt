fun main()
{    try
{
    println("Введите а")
    val a = readln().toDouble()
    println("Введите b")
    val b = readln().toDouble()
    println("Введите c")
    val c = readln().toDouble()
    println("Введите d")
    val d = readln().toDouble()
    println("Введите x")
    val x= readln().toDouble()

    if (x in a..b || x in c..d)
    {
        println("Число $x принадлежит какому-либо из отрезков или их общей части.")
    } else {
        println("Число $x не принадлежит ни одному из отрезков или их общей части.")
    }
}catch(e:Exception)
{
    println("Oshibka")
}
}