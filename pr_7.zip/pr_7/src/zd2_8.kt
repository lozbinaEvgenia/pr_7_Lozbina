import kotlin.math.*
fun main()
{
    try
    {
        println("Введите число а")
        var a= readln().toDouble()
        println("Введите число b")
        val b= readln().toDouble()
        if(a<b||a==b)
        {
            a=0.0
            println("a= $a,b= $b")
        }
        else
            println("a= $a,b= $b")
    }
   catch(e:Exception)
   {
       println("Oshibka")
   }


}