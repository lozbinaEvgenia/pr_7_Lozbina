import kotlin.math.pow
fun main()
{
   try
   {
       println("Введите первый член арифметической прогрессии")
       val a= readln().toDouble()
       println("Введите разность ващей прогрессии")
       val raz= readln().toDouble()
       println("Введите номер первого члена от которого считаем сумму")
       val d= readln().toInt()
       println("Введите номер последнего члена до которого считаем сумму")
       val n= readln().toInt()
       var sum=0.toDouble()
       for(i in d..n)
       {
         sum+=a*raz.pow(i-1)
       }
       println(sum)
   }
   catch(e:Exception)
   {
       println("Ошибка")
   }
}