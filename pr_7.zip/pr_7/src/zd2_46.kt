fun main()
{
    try
    {
        println("Введите номер дня недели")
        val num= readln().toInt()
        when(num)
        {
            1,2,3,4,5->println("Рабочий день")
            6,7->println("Выходной день")
            else->println("Нет дня недели с таким номером")
        }
    }
    catch(e:Exception)
    {
        println("Oshibka")
    }
}