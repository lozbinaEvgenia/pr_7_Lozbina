import kotlin.math.*
fun main()
{
    try
    {
        println("Введите длину треугольника")
      val A= readln().toDouble()
        println("Введите ширину треугольника")
      val B=readln().toDouble()
        println("Введите длину кирпича")
      val x=readln().toDouble()
        println("Введите ширину кирпича")
      val y=readln().toDouble()
        println("Введите высоту кирпича")
      val z=readln().toDouble()
        val plprem=A*B
        val plkirp=2*(x*y+x*z+y*z)
        if(plkirp<=plprem)
        {
            println("Кирпич проходит через отверстие")
        }
        else
        {
            println("Кирпич не проходит через отверстие")
        }
    }
    catch(e:Exception)
    {
    println("Oshibka")
    }
}