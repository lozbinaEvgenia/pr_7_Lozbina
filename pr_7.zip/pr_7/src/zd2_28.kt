fun main()
{
    try
    {
        println("Введите а")
    val a = readln().toDouble()
        println("Введите b")
    val b = readln().toDouble()
        println("Введите c")
    val c = readln().toDouble()
        println("Введите d")
    val d = readln().toDouble()
        println("Введите e")
    val e = readln().toDouble()
        println("Введите f")
    val f = readln().toDouble()

    val x = (c * e - b * f) / (a * e - b * d)
    val y = (a * f - c * d) / (a * e - b * d)

    println("Решение системы  уравнений:")
    println("x = $x")
    println("y = $y")
    }
    catch(e:Exception)
    {
        println("Oshibka")
    }
}