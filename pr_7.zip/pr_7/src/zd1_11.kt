import kotlin.math.sqrt
import kotlin.math.pow
fun main()
{
    try
    {
        println("Введите радиус окружности")
        val R= readln().toDouble()
        if(R<=0)
        {
            print("Радиус не может быть отрицательным или равным нулю")
        }
        else println("Введите сторону правильного вписанного в нее многоугольника")
        val a=readln().toDouble()
        if(a<=0)
        {
          print("Сторона не может быть отрицательной или равной нулю")
        }
        else
        {var b=0.toDouble()
        b= sqrt(2*R.pow(2.0)-2*R*sqrt(R.pow(2.0)-a.pow(2.0)/4))
        println("Сторона правильного вписанного многоугольника с удвоенным числом сторон:")
        println("%.2f".format(b))
        }
    }
    catch(e:Exception)
    {
    println("Oshibka")
    }
}