import kotlin.math.*

fun main()
{
    try
    {
        println("Введите x")
        val x = readln().toDouble()
        println("Введите y")
        val y = readln().toDouble()
        println("Введите z")
        val z = readln().toDouble()
        var a = 0.toDouble()
        var b = 0.toDouble()
        a=(3+E.pow(y-1))/(1+x.pow(2.0)*abs(y-tan(z)))
        b=1+abs(y-x)+((y-x).pow(2.0)/2)+(abs(y-x).pow(3.0)/3)
        println("a= ")
        println("%.2f".format(a))
        println("b= ")
        println("%.2f".format(b))
    }
    catch(e:Exception)
    {
        println("Oshibka")
    }
}